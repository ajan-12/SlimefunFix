package com.playtimesx;

import java.util.logging.Logger;

import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

public class PlaytimesX extends JavaPlugin{
	
}
